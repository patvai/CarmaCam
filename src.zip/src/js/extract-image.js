var dataURL;

function draw(video, thecanvas) {
  thecanvas.width = video.videoWidth;
  thecanvas.height = video.videoHeight;
  // get the canvas context for drawing
  var context = thecanvas.getContext('2d');

  // draw the video contents into the canvas x, y, width, height
  context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);

  // get the image data from the canvas object
  dataURL = thecanvas.toDataURL('image/png');

  // clear the canvas
  context.clearRect(0, 0, video.videoWidth, video.videoHeight);

  var scope = angular.element(document.getElementById('mycontroller')).scope();
  scope.$apply(function () {
    scope.updateImage(dataURL);
  });
}

var app = angular.module('app', ['ngImgCrop']);
app.controller('Ctrl', function ($scope, $sce, $http) {
  const backendUrl = 'https://carma-cam-test-backend.yj83leetest.space/9010';

  $scope.myCroppedImage = '';
  $scope.updateImage = function (dataURL) {
    $scope.myImage = dataURL;
  };

  $scope.getVideo = function () {
    const videoId = window.location.search.split('&')[0].split('=')[1];
    $scope.reportId = window.location.search.split('&')[1].split('=')[1];
    var vid = document.getElementById('video');
    vid.src = backendUrl + '/downloadFile/' + videoId;
  };

  $scope.back = () => {
    const [videoData, reportData, accountData] = window.location.search.split('&');
    const [, videoId] = videoData.split('=');
    const [, reportId] = reportData.split('=');
    const [, accountId] = accountData.split('=');
    window.location = `post-report.html?reportId=${reportId}&accountId=${accountId}`;
  };

  $scope.uploadImage = function () {
    //add check here to decide if image to be sent to report collection or alerts collection,
    // when emergency alerts are enabled
    var data = $.param({
      filefield: $scope.myCroppedImage,
      reportId: window.location.search.split('&')[1].split('=')[1],
    });

    var config = {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    };

    $scope.model = {
      reportId: window.location.search.split('&')[1].split('=')[1],
    };

    $http({
      method: 'POST',
      url: backendUrl + '/uploadImage',
      headers: { 'Content-type': undefined },
      transformRequest: function (data) {
        var formdata = new FormData();
        formdata.append('model', angular.toJson(data.model));
        formdata.append('file', data.files);
        return formdata;
      },
      data: { model: $scope.model, files: $scope.myCroppedImage },
    }).success(function (data, status, header, config) {
      // .html?videoId=xxx&reportId=xxx&accountId=xxx
      const [videoData, reportData, accountData] = window.location.search.split('&');
      const [, videoId] = videoData.split('=');
      const [, reportId] = reportData.split('=');
      const [, accountId] = accountData.split('=');
      console.log('move!');
      window.location = `post-report.html?reportId=${reportId}&accountId=${accountId}`;
    }).error(function (data, status, header, config) {
      bootbox.alert('Error!' + data);
    });
  };
});

window.onload = function () {
  // var video = document.getElementById('video');
  var thecanvas = document.getElementById('thecanvas');

  $('#capture').on('click', function () {
    draw(video, thecanvas);
  });
};
