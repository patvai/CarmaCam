const app = angular.module('AccountApp', []);
app.controller('displayData', ['$scope', '$http', ($scope, $http) => {
  const backendUrl = 'https://carma-cam-test-backend.yj83leetest.space/9010';

  // .html?accountId=xxx
  const [, accountId] = window.location.search.split('=');
  $scope.stack = [];
  $scope.result = [];
  $scope.stac = [];
  $scope.center_lat = '';
  $scope.center_lng = '';
  $scope.loadHello = () => {
    $http({
      method: 'GET',
      url: `${backendUrl}/accounts/${encodeURIComponent(accountId)}`,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      withCredentials: true,
    }).success((response) => {
      if (!response.zipcode || response.zipcode === '') {
        // if there is no zipcode field or zipcode is invalid set default center to campus
        $scope.center_lat = '34.022352';
        $scope.center_lng = '-118.285117';
      } else {
        const address = response.zipcode;
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address }, (results, status) => {
          if (status === google.maps.GeocoderStatus.OK) {
            $scope.center_lat = results[0].geometry.location.lat();
            $scope.center_lng = results[0].geometry.location.lng();
          } else {
            alert(`Geocode was not successful for the following reason: ${status}`);
          }
        });
      }

      $scope.name = `${response.fname} ${response.lname}`;
      $scope.licensePlateNo = response.licensePlate;
      $scope.phoneNo = response.phone;
      $scope.rewards = response.rewards;
      $scope.zipcode = response.zipcode;
      $scope.getReports();
    }).error(() => {
    });
  };

  const reportsIdList = []; // getting all reports objects under this user
  const AllReportsUrlList = []; // collecting link url
  const failedUrlList = []; // failed reports url list
  const successUrlList = []; // success reports url list
  const pendingUrlList = []; // under audit prograss reports url list

  let reportsIndex; // All reports url index, remove later if no use
  let pendingUrlIndex; // pending reports url index
  let passedUrlIndex; // passed reports url index
  let failedUrlIndex; // failed reports url index

  $scope.getReports = () => {
    $http({
      method: 'GET',
      url: `${backendUrl}/accounts/${$scope.phoneNo}/baddriverreports`,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      withCredentials: true,
    }).success((response) => {
      pendingUrlIndex = 0;
      passedUrlIndex = 0;
      failedUrlIndex = 0;
      // eslint-disable-next-line no-plusplus
      for (reportsIndex = 0; reportsIndex < response.length; reportsIndex++) {
        // eslint-disable-next-line no-underscore-dangle
        reportsIdList[reportsIndex] = response[reportsIndex]._id;
        if (response[reportsIndex].status === 'uploaded') {
          // eslint-disable-next-line no-plusplus
          pendingUrlList[pendingUrlIndex++] = {
            isDelete: false,
            url: `post-report.html?reportId=${reportsIdList[reportsIndex]}&accountId=${accountId}`,
          };
        }
        if (response[reportsIndex].status === 'success') {
          // eslint-disable-next-line no-plusplus
          successUrlList[passedUrlIndex++] = {
            isDelete: false,
            url: `post-report.html?reportId=${reportsIdList[reportsIndex]}&accountId=${accountId}`,
          };
        }

        if (response[reportsIndex].status === 'failure') {
          // eslint-disable-next-line no-plusplus
          failedUrlList[failedUrlIndex++] = {
            isDelete: false,
            url: `post-report.html?reportId=${reportsIdList[reportsIndex]}&accountId=${accountId}`,
          };
        }

        AllReportsUrlList[reportsIndex] = `post-report.html?id=${reportsIdList[reportsIndex]}`;
      }

      $scope.reportSum = response.length;
      $scope.pendingSum = pendingUrlList.length;
      $scope.passedSum = successUrlList.length;
      $scope.failedSum = failedUrlList.length;
      $scope.pendingReportsUrl = pendingUrlList;
      $scope.passedReportsUrl = successUrlList;
      $scope.failedReportsUrl = failedUrlList;

      $scope.allReportsUrl = angular.copy($scope.pendingReportsUrl);
      $scope.allReportsUrl.push(...$scope.passedReportsUrl);
      $scope.allReportsUrl.push(...$scope.failedReportsUrl);

      /* Remove lat-lng coordinates that are older than 30 days. */
      var today = Date.now();
      var dat = new Date(today - (30 * 24 * 60 * 60 * 1000));
      var dd = dat.getDate();
      var mm = dat.getMonth() + 1; //January is 0!
      var yyyy = dat.getFullYear();

      if (dd < 10) {
        dd = '0' + dd;
      }

      if (mm < 10) {
        mm = '0' + mm;
      }

      var expire = mm + '/' + dd + '/' + yyyy;
      //console.log("expire "+expire);

      for (var i = 0; i < response.length; i++) {
        $scope.stac.push(response[i].location.split(','));
        /*Has all lat-lng coordinates (including older than 30 days) .*/
        //console.log(response[i].date);
        if (response[i].date > expire) {
          $scope.stack.push(response[i].location.split(','));
          /*Has coordinates that are only in the last 30 days.*/
          //console.log("no expire");
        }
      }
      /* Removing duplicate lat-lng coordinates */
      var lookup = {};
      var items = $scope.stack;
      for (var item, i = 0; item = items[i++];) {

        var unique_latlng = item;
        if (!(unique_latlng in lookup)) {
          lookup[unique_latlng] = 1;
          $scope.result.push(unique_latlng);
        }
      }
    }).error(function () {
    });

  };

  $scope.removePendingReports = () => {
    const newDataList = [];
    angular.forEach($scope.pendingReportsUrl, function (v) {
      if (v.isDelete) {
        v.isDelete = false;
        const reportId = v.url.split('?')[1].split('&')[0].split('=')[1];
        $http({
          method: 'POST',
          url: `${backendUrl}/deleteBaddriverreports/${reportId}`,
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          withCredentials: true,
        }).success((data, status, header, config) => {
          // console.log('SUCCESS');
        }).error((data, status, header, config) => {
          // console.log('status : ' + status);
        });
      } else {
        newDataList.push(v);
      }
    });
    $scope.pendingReportsUrl = newDataList;
    $scope.allReportsUrl = angular.copy($scope.pendingReportsUrl);
    $scope.allReportsUrl.push(...$scope.passedReportsUrl);
    $scope.allReportsUrl.push(...$scope.failedReportsUrl);
  };

  $scope.removePassedReports = () => {
    const newDataList = [];
    angular.forEach($scope.passedReportsUrl, (v) => {
      if (v.isDelete) {
        v.isDelete = false;
        const reportId = v.url.split('?')[1].split('&')[0].split('=')[1];
        $http({
          method: 'POST',
          url: `${backendUrl}/deleteBaddriverreports/${reportId}`,
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          withCredentials: true,
        }).success((data, status, header, config) => {
          // console.log('SUCCESS');
        }).error((data, status, header, config) => {
          // console.log('status : ' + status);
        });
      } else {
        newDataList.push(v);
      }
    });
    $scope.passedReportsUrl = newDataList;
    $scope.allReportsUrl = angular.copy($scope.pendingReportsUrl);
    $scope.allReportsUrl.push(...$scope.passedReportsUrl);
    $scope.allReportsUrl.push(...$scope.failedReportsUrl);
  };

  $scope.removeFailedReports = () => {
    const newDataList = [];
    angular.forEach($scope.failedReportsUrl, (v) => {
      if (v.isDelete) {
        v.isDelete = false;
        // .../post_report.html?reportId=xxx&
        const reportId = v.url.split('?')[1].split('&')[0].split('=')[1];
        $http({
          method: 'POST',
          url: `${backendUrl}/deleteBaddriverreports/${reportId}`,
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          withCredentials: true,
        }).success((data, status, header, config) => {
          // console.log('SUCCESS');
        }).error((data, status, header, config) => {
          // console.log('status : ' + status);
        });
      } else {
        newDataList.push(v);
      }
    });
    $scope.failedReportsUrl = newDataList;
    $scope.allReportsUrl = angular.copy($scope.pendingReportsUrl);
    $scope.allReportsUrl.push(...$scope.passedReportsUrl);
    $scope.allReportsUrl.push(...$scope.failedReportsUrl);
  };

  $scope.logout = () => {
    $http.get(`${backendUrl}/logout`, { withCredentials: true }).then(() => {
      // logout success
      window.location = 'index.html';
    });
  };
}]);
